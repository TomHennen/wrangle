module.exports = require('ms');
